export {ToogleButtonComponent} from './toogle-button/toogle-button.component';
export {NgbModule} from '@ng-bootstrap/ng-bootstrap';
