import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'chat-chat-bottom-sender',
  templateUrl: './chat-bottom-sender.component.html',
  styleUrls: ['./chat-bottom-sender.component.scss']
})
export class ChatBottomSenderComponent implements OnInit {
	checkboxEvent:boolean;
	btnChk = true;
  constructor() { }

  ngOnInit() {
  }
  
  	changecheckBox(event){
		this.checkboxEvent = event.target.checked;		
	}
	keyupTextarea(event){
		let val = event.target.value;
		if(val.length > 0){
			this.btnChk = false;
		}else{
			this.btnChk = true;
		}
	}
	propagation(event){
		event.stopPropagation();
		
	}

}
