import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'chat-chat-body-messenger',
  templateUrl: './chat-body-messenger.component.html',
  styleUrls: ['./chat-body-messenger.component.scss']
})
export class ChatBodyMessengerComponent implements OnInit {
	@Input() data:any={};
  constructor() { }

  ngOnInit() {
  }

}
