import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'chat-chat-corps-msg',
  templateUrl: './chat-corps-msg.component.html',
  styleUrls: ['./chat-corps-msg.component.scss']
})
export class ChatCorpsMsgComponent implements OnInit {
	@Input() cssG:any={};
	@Input() cssIcone:any={};
	@Input() cssBody2:any={};
	@Input() cssbottom:any={};
	@Input() fixedCssED:any={};
	toogleMax = false;
	toogleShow=true;
	testing=true;
  constructor() { }

  ngOnInit() {
	  // this.hideChat();
	  window.onclick = (event: Event)=> {
		  const ele=<Element>event.target;
			if (!ele.matches('.dropbtn')) {
				let dropdowns = document.getElementsByClassName("dropdown-content");
				let i;
				for (i = 0; i < dropdowns.length; i++) {
				  let openDropdown = dropdowns[i];
				  if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				  }
				}
			}
		}

  }
	
		dropdown() {
			document.getElementById("myDropdown").classList.toggle("show");
		}
		
	maximisize(event){
		if(event == true){
			this.toogleMax = false;
			this.cssBody2={};
			
		}else{
			this.toogleMax = true;
			this.cssBody2={'width':'480px', 'height':'575px'};
			
		}
	}
	

	
	
	showChat(){
	  this.maximisize(true);
	  this.testing=false;
	  this.toogleShow = true;
	  this.fixedCssED={};
	  this.cssbottom={};
	  this.cssBody2={};
	  this.cssBody2={'display': 'block'};
  }

  hideChat(){
	  this.maximisize(true);
	  this.toogleShow = false;
	  this.fixedCssED={'display': 'none'};
	  this.cssbottom={'height': '0px', 'margin-bottom' : '-10px'};
	  this.cssBody2={'width': '200px'};
  }
  
	show_hide_Chat(){
		if(this.toogleShow == false){
			this.showChat();
		}else{
			this.hideChat();
		}
	}
	
	closeing(event){
		if(event == true){
			 this.cssBody2={'display': 'none'};
		}
	}
}
