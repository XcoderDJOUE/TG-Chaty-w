import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'chat-chat-header',
  templateUrl: './chat-header.component.html',
  styleUrls: ['./chat-header.component.scss']
})
export class ChatHeaderComponent implements OnInit {
	@Input() toogleMax:boolean;
	@Input() toogleShow:boolean;
	@Input() returntoog:boolean;
	@Input() headername="Nouveau message";
	@Output() outtoogle= new EventEmitter< boolean >();
	@Output() closedChat= new EventEmitter< boolean >();
	
	toogleEmit = true;
  constructor() { }

  ngOnInit() {
	  this.toogleMax = false;
	  this.toogleShow = true;
	  this.outtoogle.emit(true);
  }
  
  propagation(event){
		event.stopPropagation();
		
	}
	
	maximisize(){
		if(this.toogleEmit == true){
			this.toogleEmit = false;
			
			this.outtoogle.emit(false);
			
		}else{
			this.toogleEmit = true;
			this.outtoogle.emit(true);
			
		}
	}
	
	fermeture(){
		this.closedChat.emit(true);
	}


}
