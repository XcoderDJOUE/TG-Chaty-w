import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToogleButtonComponent } from './toogle-button/toogle-button.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SearchComponent } from './search/search.component';
import { ChatMembreComponent } from './chat-membre/chat-membre.component';
import { ChatCorpsMsgComponent } from './chat-corps-msg/chat-corps-msg.component';
import { ChatHeaderComponent } from './chat-header/chat-header.component';
import { ChatBodyMessengerComponent } from './chat-body-messenger/chat-body-messenger.component';
import { ChatBottomSenderComponent } from './chat-bottom-sender/chat-bottom-sender.component';
@NgModule({
  declarations: [ToogleButtonComponent, SearchComponent, ChatMembreComponent, ChatCorpsMsgComponent, ChatHeaderComponent, ChatBodyMessengerComponent, ChatBottomSenderComponent],
  exports: [
    ToogleButtonComponent
  ],
  imports: [
    CommonModule,
    NgbModule
  ]
})
export class ChatModuleModule { }
