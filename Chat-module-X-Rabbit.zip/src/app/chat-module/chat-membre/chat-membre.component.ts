import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'chat-chat-membre',
  templateUrl: './chat-membre.component.html',
  styleUrls: ['./chat-membre.component.scss']
})
export class ChatMembreComponent implements OnInit {
	@Input() indexI: number;
	@Input() data: any={};
  constructor() { }

  ngOnInit() {
  }

}
