import {Component, OnInit, Input} from '@angular/core';
@Component({
  selector: 'Chat-toogle-button',
  templateUrl: './toogle-button.component.html',
  styleUrls: ['./toogle-button.component.scss']
})
export class ToogleButtonComponent implements OnInit {
	@Input() cssG:any={};
	@Input() cssIcone:any={};
	@Input() cssBody:any={};
	@Input() cssbottom:any={};
	
	public toogleShow = false;
	public data:any={};
	public cssBodyLoard:any={};
  constructor() {
	  this.cssBodyLoard = {display: 'none'};
  }

  ngOnInit() {
	  this.hideChat();
	  this.data={nom: 'Djouekan Joel', lastMsg: 'ok compris', expediteur : 'Vous'}
  }
  
  
  showChat(){
	  this.toogleShow = true;
	  this.cssbottom={};
  }

  hideChat(){
	  this.toogleShow = false;
	  this.cssbottom={'height': '0px', 'margin-bottom' : '0px'};
  }
  
	show_hide_Chat(){
		if(this.toogleShow == false){
			this.showChat();
		}else{
			this.hideChat();
		}
	}
	
	newMessage(){
	
	}
	
	propagation(event){
		event.stopPropagation();
		
	}
}
